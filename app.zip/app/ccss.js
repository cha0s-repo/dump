var dishes = [
    {name:'宫爆鸡丁', url:'/url1', imgurl:'http://placehold.it/64x64', desc:'采用优质小雏鸡胸部仅有的多汁软嫩小鲜肉精致而成。', recomm:true, cata:1, checked:true},
    {name:'鱼香豆腐', url:'/url2', imgurl:'http://placehold.it/64x64', desc:'鲜美的白豆腐搭配爽口黑木耳浑然天成。', recomm:true, cata:2, checked:false}
];
var showcase = [
	{name:'1', url:'img/1.jpg'},
	{name:'2', url:'img/2.jpg'},
	{name:'3', url:'img/3.jpg'},
	{name:'4', url:'img/4.jpg'},			
];
var myApp = angular.module('menuApp',[]);

myApp.controller('menuListCtrl', function ($scope){
    $scope.dishes = dishes;
    $scope.showcase = showcase;

    $scope.click = function(index) {
    	var dish = $scope.dishes[index];
    	dish.checked = !dish.checked;
    }

    $scope.checkCount = function () {
	    var count = 0;
	    angular.forEach($scope.dishes, function (item) {
	        if (item.checked) { count++ }
	    });
	    return count;
	}
});